const { Solver } = require("@2captcha/captcha-solver");
const axios = require("axios");
const config = require("../../config");
const { logMessage } = require("./logger");

module.exports = class CaptchaService {
  constructor() {
    this.sitekey = "a084602b-6a75-4a16-86e7-d708ba73e8ef";
    this.pageUrl = "https://scrapeops.io/";
    this.antiCaptchaApiUrl = "https://api.anti-captcha.com";
  }

  async solveCaptcha(currentNum, total) {
    const provider = config.captchaServices.captchaUsing;
    if (provider === "captcha2") {
      return this.Captcha2(currentNum, total);
    } else if (provider === "antiCaptcha") {
      return this.antiCaptcha(currentNum, total);
    } else {
      throw new Error("Invalid captcha provider");
    }
  }

  async antiCaptcha(currentNum, total) {
    logMessage(
      currentNum,
      total,
      "Trying solving captcha Hcaptcha ...",
      "process"
    );
    const apiKey = config.captchaServices.antiCaptchaApikey[0];

    try {
      const createTaskResponse = await axios.post(
        `${this.antiCaptchaApiUrl}/createTask`,
        {
          clientKey: apiKey,
          task: {
            type: "HCaptchaTaskProxyless",
            websiteURL: this.pageUrl,
            websiteKey: this.sitekey,
          },
          softId: 0,
        }
      );

      const taskId = createTaskResponse.data.taskId;
      if (!taskId) throw new Error("Failed to get task ID");

      logMessage(
        currentNum,
        total,
        `Task created with ID: ${taskId}`,
        "process"
      );
      let result = null;
      while (!result) {
        await new Promise((resolve) => setTimeout(resolve, 5000));

        const getResultResponse = await axios.post(
          `${this.antiCaptchaApiUrl}/getTaskResult`,
          {
            clientKey: apiKey,
            taskId: taskId,
          }
        );

        if (getResultResponse.data.status === "ready") {
          result = getResultResponse.data.solution.gRecaptchaResponse;
          logMessage(
            currentNum,
            total,
            "Captcha solved successfully!",
            "success"
          );
        }
      }

      return result;
    } catch (error) {
      logMessage(
        currentNum,
        total,
        `AntiCaptcha failed: ${error.message}`,
        "error"
      );
      return null;
    }
  }

  async Captcha2(currentNum, total) {
    logMessage(
      currentNum,
      total,
      "Trying solving captcha Recaptcha...",
      "process"
    );
    const apikey = config.captchaServices.captcha2Apikey[0];
    try {
      const res = await new Solver(apikey).recaptcha({
        pageurl: this.pageUrl,
        googlekey: this.sitekey,
        version: "v3",
        min_score: "0.8",
      });
      return res.data;
    } catch (error) {
      logMessage(
        currentNum,
        total,
        `2Captcha failed ${error.message}`,
        "error"
      );
      return null;
    }
  }
};
