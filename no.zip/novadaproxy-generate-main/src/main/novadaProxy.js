const axios = require("axios");
const { logMessage } = require("../utils/logger");
const { getProxyAgent } = require("./proxy");
const generator = new (require("../utils/generator"))();
const UserAgent = require("user-agents");
const { faker } = require("@faker-js/faker");

module.exports = class novadaProxy {
  constructor(proxy = null, currentNum, total) {
    this.proxy = proxy;
    this.currentNum = currentNum;
    this.total = total;
    this.userAgent = new UserAgent().toString();
    this.captcha = new (require("../utils/captchaServices"))(
      this.proxy,
      this.userAgent
    );
    this.axios = axios.create({
      httpsAgent: proxy ? getProxyAgent(proxy) : undefined,
      timeout: 120000,
      headers: {
        "User-Agent": new UserAgent().toString(),
      },
    });
  }

  async makeRequest(method, url, config = {}, retries = 3) {
    for (let i = 0; i < retries; i++) {
      try {
        return await this.axios({ method, url, ...config });
      } catch (error) {
        const errorData = error.response ? error.response.data : error.message;
        logMessage(
          this.currentNum,
          this.total,
          `Request failed: ${error.message}`,
          "error"
        );
        logMessage(
          this.currentNum,
          this.total,
          `Error response data: ${JSON.stringify(errorData, null, 2)}`,
          "error"
        );

        logMessage(
          this.currentNum,
          this.total,
          `Retrying... (${i + 1}/${retries})`,
          "process"
        );
        await new Promise((resolve) => setTimeout(resolve, 12000));
      }
    }
    return null;
  }

  async getRandomDomain() {
    logMessage(
      this.currentNum,
      this.total,
      "Trying to get a random domain...",
      "process"
    );
    const vowels = "aeiou";
    const consonants = "bcdfghjklmnpqrstvwxyz";
    const keyword =
      consonants[Math.floor(Math.random() * consonants.length)] +
      vowels[Math.floor(Math.random() * vowels.length)];
    try {
      const response = await this.makeRequest(
        "GET",
        `https://generator.email/search.php?key=${keyword}`
      );

      if (!response) {
        logMessage(
          this.currentNum,
          this.total,
          "No response from API",
          "error"
        );
        return null;
      }
      const domains = response.data.filter((d) => /^[\x00-\x7F]*$/.test(d));
      if (domains.length) {
        const selectedDomain =
          domains[Math.floor(Math.random() * domains.length)];
        logMessage(
          this.currentNum,
          this.total,
          `Selected domain: ${selectedDomain}`,
          "success"
        );
        return selectedDomain;
      }

      logMessage(
        this.currentNum,
        this.total,
        "Could not find valid domain",
        "error"
      );
      return null;
    } catch (error) {
      logMessage(
        this.currentNum,
        this.total,
        `Error getting random domain: ${error.message}`,
        "error"
      );
      return null;
    }
  }

  async generateEmail(domain) {
    logMessage(
      this.currentNum,
      this.total,
      "Trying to generate email...",
      "process"
    );

    const firstname = faker.person.firstName().toLowerCase();
    const lastname = faker.person.lastName().toLowerCase();
    const randomNums = Math.floor(Math.random() * 900 + 100).toString();

    const separator = Math.random() > 0.5 ? "" : ".";
    const email = `${firstname}${separator}${lastname}${randomNums}@${domain}`;

    logMessage(
      this.currentNum,
      this.total,
      `Generated email: ${email}`,
      "success"
    );
    return email;
  }
  async getCodeVerification(email, domain) {
    logMessage(
      this.currentNum,
      this.total,
      "Trying to get verification code...",
      "process"
    );

    const cookies = {
      embx: `%22${email}%22`,
      surl: `${domain}/${email.split("@")[0]}`,
    };

    const headers = {
      Cookie: Object.entries(cookies)
        .map(([key, value]) => `${key}=${value}`)
        .join("; "),
    };

    const maxAttempts = 5;
    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      logMessage(
        this.currentNum,
        this.total,
        `Attempt ${attempt} Checking for verification code...`,
        "process"
      );

      try {
        const response = await this.makeRequest(
          "GET",
          "https://generator.email/inbox1/",
          { headers: headers }
        );
        if (!response || !response.data) {
          logMessage(
            this.currentNum,
            this.total,
            "No response from email server",
            "warning"
          );
          continue;
        }

        const codeRegex = /<div class="code">(\d{6})<\/div>/;
        const codeMatch = response.data.match(codeRegex);

        const linkRegex =
          /https:\/\/novada\.com\/verifyReset\?email=([^&]+)&(?:amp;)?code=(\d+)/;
        const linkMatch = response.data.match(linkRegex);
        if (linkMatch && linkMatch[2]) {
          const verificationCode = linkMatch[2];
          const encodedEmail = linkMatch[1];

          logMessage(
            this.currentNum,
            this.total,
            `Verification link found! Code: ${verificationCode}, Encoded Email: ${encodedEmail}`,
            "success"
          );

          return { emailEncode: encodedEmail, code: verificationCode };
        } else if (codeMatch && codeMatch[1]) {
          const activeCode = codeMatch[1];
          logMessage(
            this.currentNum,
            this.total,
            `Verification Found in div: ${activeCode}`,
            "success"
          );
          return activeCode;
        }
        logMessage(
          this.currentNum,
          this.total,
          "Verification code not found, retrying...",
          "warning"
        );
      } catch (error) {
        logMessage(
          this.currentNum,
          this.total,
          `Error getting verification code: ${error.message}`,
          "error"
        );
      }

      await new Promise((resolve) => setTimeout(resolve, 10000));
    }

    logMessage(
      this.currentNum,
      this.total,
      "Failed to retrieve active code after maximum attempts",
      "error"
    );
    return null;
  }
  async registerAccount(email, password) {
    logMessage(
      this.currentNum,
      this.total,
      "Trying to register account...",
      "process"
    );

    const formDataObj = {
      email,
      password,
      is_agree: 1,
      auto_login: 0,
      phone: "",
      area_code: "",
      is_wap: "",
      token: "",
    };

    const formData = new URLSearchParams(formDataObj);

    const headers = {
      origin: "https://www.novada.com",
      Referer: "https://www.novada.com/",
    };

    try {
      const response = await this.makeRequest(
        "POST",
        "https://api.novada.com/g/api/account/accountRegister",
        {
          headers: headers,
          data: formData,
        }
      );
      if (response.data && response.data.code === 0) {
        logMessage(
          this.currentNum,
          this.total,
          "Account registered",
          "success"
        );
        return response.data;
      } else {
        logMessage(
          this.currentNum,
          this.total,
          "Account not registered",
          "error"
        );
        return null;
      }
    } catch (error) {
      logMessage(
        this.currentNum,
        this.total,
        `Error register account, message: ${error.message}`,
        "error"
      );
      return null;
    }
  }
  async verifiactionAccount(email, code) {
    logMessage(this.currentNum, this.total, "Verifying account...", "process");

    const formData = new URLSearchParams({
      email,
      code,
    });

    const headers = {
      origin: "https://www.novada.com",
      Referer: "https://www.novada.com/",
    };

    try {
      const response = await this.makeRequest(
        "POST",
        "https://api.novada.com/g/api/account/activation",
        {
          data: formData,
          headers: headers,
        }
      );

      if (response.data && response.data.code === 0) {
        logMessage(
          this.currentNum,
          this.total,
          "Account verified successfully",
          "success"
        );
        return response.data.data.token;
      } else {
        logMessage(
          this.currentNum,
          this.total,
          "Account verification failed",
          "error"
        );
        return null;
      }
    } catch (error) {
      logMessage(
        this.currentNum,
        this.total,
        `Error verifying account, message: ${error.message}`,
        "error"
      );
      return null;
    }
  }
  async unlockFreeTrial(token) {
    logMessage(this.currentNum, this.total, "Getting free trial...", "process");

    const headers = {
      origin: "https://dashboard.novada.com",
      Referer: "https://dashboard.novada.com",
      authorization: `${token}`,
    };

    const formData = new URLSearchParams({
      source: 1,
      type: "unblocker_flow",
      pay_type: "Free",
      money: 0,
      num: 1,
      package_id: 22,
      duration: 7,
    });

    try {
      const response = await this.makeRequest(
        "POST",
        "https://api.novada.com/g/api/order/add",
        {
          data: formData,
          headers: headers,
        }
      );
      if (response.data && response.data.code === 0) {
        logMessage(
          this.currentNum,
          this.total,
          "Free trial unlocked successfully",
          "success"
        );
        return response.data;
      } else {
        logMessage(
          this.currentNum,
          this.total,
          "Failed to unlock free trial",
          "error"
        );
        return null;
      }
    } catch (error) {
      logMessage(
        this.currentNum,
        this.total,
        `Error unlocking free trial, message: ${error.message}`,
        "error"
      );
      return null;
    }
  }
  async createProxyAccount(token, username, password) {
    logMessage(
      this.currentNum,
      this.total,
      "Creating proxy account...",
      "process"
    );

    const headers = {
      origin: "https://dashboard.novada.com",
      Referer: "https://dashboard.novada.com",
      authorization: `${token}`,
    };

    const formData = new URLSearchParams({
      account: username,
      password: password,
      status: 1,
      limit_flow: 0,
      product: 7,
    });

    try {
      const response = await this.makeRequest(
        "POST",
        "https://api.novada.com/g/api/proxy_account/proxy_account_create",
        {
          data: formData,
          headers: headers,
        }
      );
      if (response.data && response.data.code === 0) {
        logMessage(
          this.currentNum,
          this.total,
          "Proxy account created successfully",
          "success"
        );
        return response.data;
      } else {
        logMessage(
          this.currentNum,
          this.total,
          "Failed to create proxy account",
          "error"
        );
        return null;
      }
    } catch (error) {
      logMessage(
        this.currentNum,
        this.total,
        `Error creating proxy account, message: ${error.message}`,
        "error"
      );
      return null;
    }
  }

  async singleProses() {
    logMessage(
      this.currentNum,
      this.total,
      "Proccesing register account",
      "debug"
    );
    try {
      const domain = await this.getRandomDomain();
      if (!domain) return;
      const email = await this.generateEmail(domain);
      if (!email) return;
      const password = await generator.Password();
      const usernameProxy = await generator.RandomUsername();
      const passwordProxy = await generator.RandomPassword12();
      const registerResponse = await this.registerAccount(email, password);
      if (!registerResponse) return;
      const { emailEncode, code } = await this.getCodeVerification(
        email,
        domain
      );
      if (!emailEncode) return;

      const token = await this.verifiactionAccount(emailEncode, code);
      if (!token) return;
      const unlockResponse = await this.unlockFreeTrial(token);
      if (!unlockResponse) return;
      const createProxyResponse = await this.createProxyAccount(
        token,
        usernameProxy,
        passwordProxy
      );
      if (!createProxyResponse) return;
      return { username: usernameProxy, password: passwordProxy };
    } catch (error) {
      logMessage(
        this.currentNum,
        this.total,
        `Error proses register, message : ${error.message}`,
        "error"
      );
      return null;
    }
  }
};
