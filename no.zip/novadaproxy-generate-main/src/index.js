const { prompt, logMessage, rl } = require("./utils/logger");
const novadaProxy = require("./main/novadaProxy");
const { getRandomProxy, loadProxies } = require("./main/proxy");
const chalk = require("chalk");
const fs = require("fs");

async function main() {
  console.log(
    chalk.cyan(`
░█▀█░█▀█░█░█░█▀█░█▀▄░█▀█
░█░█░█░█░▀▄▀░█▀█░█░█░█▀█
░▀░▀░▀▀▀░░▀░░▀░▀░▀▀░░▀░▀
    By : El Puqus Airdrop
    github.com/ahlulmukh
  `)
  );

  const count = parseInt(await prompt(chalk.yellow("How many do you want? ")));
  const proxiesLoaded = loadProxies();
  if (!proxiesLoaded) {
    logMessage(null, null, "No Proxy. Using default IP", "warning");
  }
  const apikey = fs.createWriteStream("proxyfile.txt", { flags: "a" });
  let successful = 0;
  let attempt = 1;

  try {
    while (successful < count) {
      console.log(chalk.white("-".repeat(85)));
      const currentProxy = await getRandomProxy(successful + 1, count);
      const scrape = new novadaProxy(currentProxy, successful + 1, count);
      try {
        const account = await scrape.singleProses();

        if (account) {
          apikey.write(
            `${account.username}-zone-unblock-region-us:${account.password}@super.novada.pro:7777\n`
          );
          successful++;
          logMessage(
            successful,
            count,
            `Apikey : ${account.username}`,
            "success"
          );
          attempt = 1;
        } else {
          logMessage(
            successful + 1,
            count,
            "Register Account Failed, retrying...",
            "error"
          );
          attempt++;
        }
      } catch (error) {
        logMessage(
          successful + 1,
          count,
          `Error: ${error.message}, retrying...`,
          "error"
        );
        attempt++;
      }
    }
  } finally {
    apikey.end();
    console.log(chalk.magenta("\n[*] Dono bang!"));
    console.log(
      chalk.green(`[*] Account dono ${successful} dari ${count} akun`)
    );
    console.log(chalk.magenta("[*] Result in proxyfile.txt"));
    rl.close();
  }
}

main();
