scrapeops

config.js

````js
module.exports = {
  captchaServices: {
    captchaUsing: "antiCaptcha", // antiCaptcha // Captcha2
    captcha2Apikey: [""],
    antiCaptchaApikey: [""],
  },
};
```
````
